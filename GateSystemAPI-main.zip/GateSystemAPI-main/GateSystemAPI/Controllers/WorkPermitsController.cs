﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GateSystemAPI.Data;
using GateSystemAPI.Models;
using GateSystemAPI.Models.DTOs;

namespace GateSystemAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class WorkPermitsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public WorkPermitsController(AppDbContext context)
        {
            _context = context;
        }

        // GET api/workpermits
        [HttpGet]
        public async Task<ActionResult<IEnumerable<WorkPermit>>> GetAll()
        {
            return await _context.WorkPermits
                .OrderByDescending(p => p.CreatedAt)
                .ToListAsync();
        }

        // GET api/workpermits/5
        [HttpGet("{id}")]
        public async Task<ActionResult<WorkPermit>> GetById(int id)
        {
            var permit = await _context.WorkPermits.FindAsync(id);
            if (permit == null)
                return NotFound();

            return permit;
        }

        // POST api/workpermits
        [HttpPost]
        public async Task<ActionResult<WorkPermit>> Create(WorkPermitCreateDto dto)
        {
            var countThisYear = await _context.WorkPermits
                .CountAsync(p => p.CreatedAt.Year == DateTime.Now.Year);

            var permitNumber = $"WP-{DateTime.Now.Year}-{(countThisYear + 1):D4}";

            var permit = new WorkPermit
            {
                PermitNumber = permitNumber,
                PermitType = dto.PermitType,
                WorkLocation = dto.WorkLocation,
                WorkDescription = dto.WorkDescription,
                Hazards = dto.Hazards,
                ControlMeasures = dto.ControlMeasures,
                PpeRequired = dto.PpeRequired,
                IsolationLoto = dto.IsolationLoto,
                StartDateTime = dto.StartDateTime,
                EndDateTime = dto.EndDateTime,
                ExtensionRequired = dto.ExtensionRequired,
                Requester = dto.Requester,
                Status = "Pending",
                CreatedAt = DateTime.Now,
            };

            _context.WorkPermits.Add(permit);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = permit.Id }, permit);
        }

        // PUT api/workpermits/5/approve-supervisor
        [HttpPut("{id}/approve-supervisor")]
        public async Task<IActionResult> ApproveSupervisor(int id)
        {
            return await SetApproval(id, p => p.SupervisorApproved = true);
        }

        // PUT api/workpermits/5/approve-hse
        [HttpPut("{id}/approve-hse")]
        public async Task<IActionResult> ApproveHse(int id)
        {
            return await SetApproval(id, p => p.HseApproved = true);
        }

        // PUT api/workpermits/5/approve-security
        [HttpPut("{id}/approve-security")]
        public async Task<IActionResult> ApproveSecurity(int id)
        {
            return await SetApproval(id, p => p.SecurityApproved = true);
        }

        // PUT api/workpermits/5/reject
        [HttpPut("{id}/reject")]
        public async Task<IActionResult> Reject(int id)
        {
            var permit = await _context.WorkPermits.FindAsync(id);
            if (permit == null)
                return NotFound();

            permit.Status = "Rejected";
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // PUT api/workpermits/5/close
        [HttpPut("{id}/close")]
        public async Task<IActionResult> Close(int id)
        {
            var permit = await _context.WorkPermits.FindAsync(id);
            if (permit == null)
                return NotFound();

            permit.Status = "Closed";
            await _context.SaveChangesAsync();
            return NoContent();
        }

        private async Task<IActionResult> SetApproval(int id, Action<WorkPermit> setFlag)
        {
            var permit = await _context.WorkPermits.FindAsync(id);
            if (permit == null)
                return NotFound();

            setFlag(permit);

            if (permit.SupervisorApproved == true && permit.HseApproved == true && permit.SecurityApproved == true)
            {
                permit.Status = "Approved";
            }

            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}