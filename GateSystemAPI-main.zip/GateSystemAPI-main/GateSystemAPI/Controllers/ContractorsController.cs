﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GateSystemAPI.Data;
using GateSystemAPI.Models;
using GateSystemAPI.Models.DTOs;

namespace GateSystemAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ContractorsController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _env;

        public ContractorsController(AppDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        // GET api/contractors/lookup/01012345678
        [HttpGet("lookup/{phoneNumber}")]
        public async Task<ActionResult<Contractor>> Lookup(string phoneNumber)
        {
            var contractor = await _context.Contractors
                .FirstOrDefaultAsync(c => c.PhoneNumber == phoneNumber);

            if (contractor == null)
                return NotFound();

            return contractor;
        }

        // GET api/contractors
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Contractor>>> GetAll()
        {
            return await _context.Contractors.ToListAsync();
        }

        // GET api/contractors/companies
        [HttpGet("companies")]
        public async Task<ActionResult<object>> GetByCompany()
        {
            var grouped = await _context.Contractors
                .GroupBy(c => c.CompanyName)
                .Select(g => new
                {
                    companyName = g.Key,
                    personnelCount = g.Count(),
                    personnel = g.ToList()
                })
                .OrderBy(g => g.companyName)
                .ToListAsync();

            return Ok(grouped);
        }

        // POST api/contractors
        [HttpPost]
        public async Task<ActionResult<Contractor>> Create(Contractor contractor)
        {
            _context.Contractors.Add(contractor);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Lookup), new { phoneNumber = contractor.PhoneNumber }, contractor);
        }

        // PUT api/contractors/5/blacklist
        [HttpPut("{id}/blacklist")]
        public async Task<IActionResult> SetBlacklist(int id, [FromBody] bool isBlacklisted)
        {
            var contractor = await _context.Contractors.FindAsync(id);
            if (contractor == null)
                return NotFound();

            contractor.IsBlacklisted = isBlacklisted;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // PUT api/contractors/5/classification
        [HttpPut("{id}/classification")]
        public async Task<IActionResult> UpdateClassification(int id, [FromBody] ContractorClassificationDto dto)
        {
            var contractor = await _context.Contractors.FindAsync(id);
            if (contractor == null)
                return NotFound();

            contractor.ContractorType = dto.ContractorType;
            contractor.RiskCategory = dto.RiskCategory;
            contractor.AccessEligibility = dto.AccessEligibility;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // GET api/contractors/5/details
        [HttpGet("{id}/details")]
        public async Task<ActionResult<object>> GetDetails(int id)
        {
            var contractor = await _context.Contractors.FindAsync(id);
            if (contractor == null)
                return NotFound();

            var visits = await _context.VisitLogs
                .Where(v => v.ContractorId == id)
                .OrderByDescending(v => v.EntryTime)
                .ToListAsync();

            var documents = await _context.ContractorDocuments
                .Where(d => d.ContractorId == id)
                .OrderBy(d => d.ExpiryDate)
                .ToListAsync();

            return Ok(new
            {
                contractor.Id,
                contractor.FullName,
                contractor.CompanyName,
                contractor.PhoneNumber,
                contractor.NationalId,
                contractor.IsBlacklisted,
                contractor.Notes,
                contractor.ContractorType,
                contractor.RiskCategory,
                contractor.AccessEligibility,
                visits,
                documents
            });
        }

        // PUT api/contractors/5/notes
        [HttpPut("{id}/notes")]
        public async Task<IActionResult> UpdateNotes(int id, [FromBody] string? notes)
        {
            var contractor = await _context.Contractors.FindAsync(id);
            if (contractor == null)
                return NotFound();

            contractor.Notes = notes;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // POST api/contractors/5/documents
        [HttpPost("{id}/documents")]
        public async Task<ActionResult<ContractorDocument>> AddDocument(int id, ContractorDocumentCreateDto dto)
        {
            var contractor = await _context.Contractors.FindAsync(id);
            if (contractor == null)
                return NotFound();

            var document = new ContractorDocument
            {
                ContractorId = id,
                DocumentType = dto.DocumentType,
                DocumentNumber = dto.DocumentNumber,
                IssueDate = dto.IssueDate,
                ExpiryDate = dto.ExpiryDate,
                CreatedAt = DateTime.Now,
            };

            _context.ContractorDocuments.Add(document);
            await _context.SaveChangesAsync();
            return Ok(document);
        }

        // POST api/contractors/documents/5/upload
        [HttpPost("documents/{documentId}/upload")]
        public async Task<IActionResult> UploadDocumentFile(int documentId, IFormFile file)
        {
            var document = await _context.ContractorDocuments.FindAsync(documentId);
            if (document == null)
                return NotFound();

            if (file == null || file.Length == 0)
                return BadRequest("مفيش ملف اتبعت.");

            var folder = Path.Combine(_env.WebRootPath, "contractor-documents");
            Directory.CreateDirectory(folder);

            var fileName = $"{Guid.NewGuid()}_{file.FileName}";
            var fullPath = Path.Combine(folder, fileName);

            using (var stream = new FileStream(fullPath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            document.AttachmentPath = $"/contractor-documents/{fileName}";
            await _context.SaveChangesAsync();

            return Ok(new { path = document.AttachmentPath });
        }
    }
}