﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GateSystemAPI.Data;
using GateSystemAPI.Models;
using GateSystemAPI.Models.DTOs;

namespace GateSystemAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class InspectionsController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _env;

        public InspectionsController(AppDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        // GET api/inspections
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Inspection>>> GetAll()
        {
            return await _context.Inspections
                .OrderByDescending(i => i.CreatedAt)
                .ToListAsync();
        }

        // GET api/inspections/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Inspection>> GetById(int id)
        {
            var inspection = await _context.Inspections.FindAsync(id);
            if (inspection == null)
                return NotFound();

            return inspection;
        }

        // POST api/inspections
        [HttpPost]
        public async Task<ActionResult<Inspection>> Create(InspectionCreateDto dto)
        {
            var inspection = new Inspection
            {
                InspectionType = dto.InspectionType,
                AreaOrAsset = dto.AreaOrAsset,
                Inspector = dto.Inspector,
                InspectionDate = dto.InspectionDate,
                ChecklistItem = dto.ChecklistItem,
                Result = dto.Result,
                RiskLevel = dto.RiskLevel,
                Comment = dto.Comment,
                FindingDescription = dto.FindingDescription,
                ImmediateAction = dto.ImmediateAction,
                ActionOwner = dto.ActionOwner,
                DueDate = dto.DueDate,
                Priority = dto.Priority,
                ActionStatus = string.IsNullOrWhiteSpace(dto.ActionOwner) ? "N/A" : "Open",
                CreatedAt = DateTime.Now,
            };

            _context.Inspections.Add(inspection);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = inspection.Id }, inspection);
        }

        // POST api/inspections/5/upload-photo
        [HttpPost("{id}/upload-photo")]
        public async Task<IActionResult> UploadPhoto(int id, IFormFile file)
        {
            var inspection = await _context.Inspections.FindAsync(id);
            if (inspection == null)
                return NotFound();

            if (file == null || file.Length == 0)
                return BadRequest("مفيش صورة اتبعتت.");

            var photosFolder = Path.Combine(_env.WebRootPath, "inspection-photos");
            Directory.CreateDirectory(photosFolder);

            var fileName = $"{Guid.NewGuid()}_{file.FileName}";
            var fullPath = Path.Combine(photosFolder, fileName);

            using (var stream = new FileStream(fullPath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            inspection.PhotoPath = $"/inspection-photos/{fileName}";
            await _context.SaveChangesAsync();

            return Ok(new { path = inspection.PhotoPath });
        }

        // PUT api/inspections/5/close-action
        [HttpPut("{id}/close-action")]
        public async Task<IActionResult> CloseAction(int id)
        {
            var inspection = await _context.Inspections.FindAsync(id);
            if (inspection == null)
                return NotFound();

            inspection.ActionStatus = "Closed";
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}