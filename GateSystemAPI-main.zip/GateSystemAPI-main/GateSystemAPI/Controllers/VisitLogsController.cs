﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GateSystemAPI.Data;
using GateSystemAPI.Models;
using GateSystemAPI.Models.DTOs;

namespace GateSystemAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VisitLogsController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _env;

        public VisitLogsController(AppDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        // GET api/visitlogs/current
        [HttpGet("current")]
        public async Task<ActionResult<IEnumerable<VisitLog>>> GetCurrent()
        {
            return await _context.VisitLogs
                .Include(v => v.Contractor)
                .Where(v => v.ExitTime == null)
                .OrderByDescending(v => v.EntryTime)
                .ToListAsync();
        }

        // GET api/visitlogs/history?fromDate=&toDate=&contractorName=&status=
        [HttpGet("history")]
        public async Task<ActionResult<IEnumerable<VisitLog>>> GetHistory(
            [FromQuery] DateTime? fromDate,
            [FromQuery] DateTime? toDate,
            [FromQuery] string? contractorName,
            [FromQuery] string? status)
        {
            var query = _context.VisitLogs
                .Include(v => v.Contractor)
                .AsQueryable();

            if (fromDate.HasValue)
                query = query.Where(v => v.EntryTime >= fromDate.Value);

            if (toDate.HasValue)
                query = query.Where(v => v.EntryTime <= toDate.Value);

            if (!string.IsNullOrWhiteSpace(contractorName))
                query = query.Where(v => v.Contractor != null && v.Contractor.FullName.Contains(contractorName));

            if (!string.IsNullOrWhiteSpace(status))
                query = query.Where(v => v.Status == status);

            return await query
                .OrderByDescending(v => v.EntryTime)
                .ToListAsync();
        }

        // POST api/visitlogs/entry
        [HttpPost("entry")]
        public async Task<ActionResult<VisitLog>> Entry(VisitLogCreateDto dto)
        {
            var visitLog = new VisitLog
            {
                ContractorId = dto.ContractorId,
                RecordedByUserId = dto.RecordedByUserId,
                VisitReason = dto.VisitReason,
                EntryTime = DateTime.Now,

                HostEmployee = dto.HostEmployee,
                Department = dto.Department,
                ApprovalRequired = dto.ApprovalRequired,
                AccessArea = dto.AccessArea,
                BadgeNumber = dto.BadgeNumber,
                MobileOrId = dto.MobileOrId,
                VisitPurpose = dto.VisitPurpose,
                ExpectedTime = dto.ExpectedTime,
                Status = dto.Status,
                Notes = dto.Notes
            };

            _context.VisitLogs.Add(visitLog);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetCurrent), new { id = visitLog.Id }, visitLog);
        }

        // PUT api/visitlogs/5/exit
        [HttpPut("{id}/exit")]
        public async Task<IActionResult> Exit(int id)
        {
            var visitLog = await _context.VisitLogs.FindAsync(id);
            if (visitLog == null)
                return NotFound();

            visitLog.ExitTime = DateTime.Now;
            visitLog.DurationMinutes = (int)(visitLog.ExitTime.Value - visitLog.EntryTime).TotalMinutes;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // PUT api/visitlogs/5
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, VisitLogUpdateDto dto)
        {
            var visitLog = await _context.VisitLogs.FindAsync(id);
            if (visitLog == null)
                return NotFound();

            visitLog.HostEmployee = dto.HostEmployee;
            visitLog.Department = dto.Department;
            visitLog.ApprovalRequired = dto.ApprovalRequired;
            visitLog.AccessArea = dto.AccessArea;
            visitLog.BadgeNumber = dto.BadgeNumber;
            visitLog.MobileOrId = dto.MobileOrId;
            visitLog.VisitPurpose = dto.VisitPurpose;
            visitLog.ExpectedTime = dto.ExpectedTime;
            visitLog.Status = dto.Status;
            visitLog.Notes = dto.Notes;

            await _context.SaveChangesAsync();
            return NoContent();
        }

        // PUT api/visitlogs/5/approve
        [HttpPut("{id}/approve")]
        public async Task<IActionResult> Approve(int id)
        {
            var visitLog = await _context.VisitLogs.FindAsync(id);
            if (visitLog == null)
                return NotFound();

            visitLog.Status = "Approved";
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // PUT api/visitlogs/5/reject
        [HttpPut("{id}/reject")]
        public async Task<IActionResult> Reject(int id)
        {
            var visitLog = await _context.VisitLogs.FindAsync(id);
            if (visitLog == null)
                return NotFound();

            visitLog.Status = "Rejected";
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // POST api/visitlogs/5/upload-permit
        [HttpPost("{id}/upload-permit")]
        public async Task<IActionResult> UploadPermit(int id, IFormFile file)
        {
            var visitLog = await _context.VisitLogs.FindAsync(id);
            if (visitLog == null)
                return NotFound();

            if (file == null || file.Length == 0)
                return BadRequest("Mafeesh file etba3at.");

            var permitsFolder = Path.Combine(_env.WebRootPath, "permits");
            Directory.CreateDirectory(permitsFolder);

            var fileName = $"{Guid.NewGuid()}_{file.FileName}";
            var fullPath = Path.Combine(permitsFolder, fileName);

            using (var stream = new FileStream(fullPath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            visitLog.PermitFilePath = $"/permits/{fileName}";
            await _context.SaveChangesAsync();

            return Ok(new { path = visitLog.PermitFilePath });
        }

        // GET api/visitlogs/dashboard-stats
        [HttpGet("dashboard-stats")]
        public async Task<ActionResult<object>> GetDashboardStats()
        {
            var today = DateTime.Today;

            var visitorsToday = await _context.VisitLogs
                .Where(v => v.EntryTime >= today)
                .CountAsync();

            var openIncidents = await _context.Incidents
                .Where(i => i.Status != "Closed")
                .CountAsync();

            var inspectionsDue = await _context.Inspections
                .Where(i => i.ActionStatus == "Open" && i.DueDate != null && i.DueDate >= today)
                .CountAsync();

            var overdueActions = await _context.Inspections
                .Where(i => i.ActionStatus == "Open" && i.DueDate != null && i.DueDate < today)
                .CountAsync();

            return Ok(new
            {
                visitorsToday,
                openIncidents,
                inspectionsDue,
                overdueActions,
            });
        }

        // GET api/visitlogs/reports/by-category?year=2026&month=8
        [HttpGet("reports/by-category")]
        public async Task<ActionResult<object>> GetReportByCategory([FromQuery] int year, [FromQuery] int month)
        {
            var visits = await _context.VisitLogs
                .Include(v => v.Contractor)
                .Where(v => v.EntryTime.Year == year && v.EntryTime.Month == month)
                .ToListAsync();

            var grouped = visits
                .GroupBy(v => string.IsNullOrWhiteSpace(v.Contractor?.ContractorType) ? "غير محدد" : v.Contractor.ContractorType)
                .Select(g => new { category = g.Key, count = g.Count() })
                .OrderByDescending(g => g.count)
                .ToList();

            return Ok(new
            {
                year,
                month,
                totalVisits = visits.Count,
                categories = grouped
            });
        }
    }
}