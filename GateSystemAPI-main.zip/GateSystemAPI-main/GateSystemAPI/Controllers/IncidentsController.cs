﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GateSystemAPI.Data;
using GateSystemAPI.Models;
using GateSystemAPI.Models.DTOs;

namespace GateSystemAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class IncidentsController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _env;

        public IncidentsController(AppDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        // GET api/incidents
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Incident>>> GetAll()
        {
            return await _context.Incidents
                .OrderByDescending(i => i.CreatedAt)
                .ToListAsync();
        }

        // GET api/incidents/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Incident>> GetById(int id)
        {
            var incident = await _context.Incidents.FindAsync(id);
            if (incident == null)
                return NotFound();

            return incident;
        }

        // POST api/incidents
        [HttpPost]
        public async Task<ActionResult<Incident>> Create(IncidentCreateDto dto)
        {
            var countThisYear = await _context.Incidents
                .CountAsync(i => i.CreatedAt.Year == DateTime.Now.Year);

            var incidentNumber = $"INC-{DateTime.Now.Year}-{(countThisYear + 1):D4}";

            var incident = new Incident
            {
                IncidentNumber = incidentNumber,
                IncidentType = dto.IncidentType,
                IncidentDateTime = dto.IncidentDateTime,
                Location = dto.Location,
                PersonsInvolved = dto.PersonsInvolved,
                ReportedBy = dto.ReportedBy,
                Description = dto.Description,
                InitialSeverity = dto.InitialSeverity,
                ImmediateAction = dto.ImmediateAction,
                Investigator = dto.Investigator,
                RootCause = dto.RootCause,
                CorrectiveAction = dto.CorrectiveAction,
                ResponsiblePerson = dto.ResponsiblePerson,
                DueDate = dto.DueDate,
                VerificationStatus = dto.VerificationStatus,
                Status = "Reported",
                CreatedAt = DateTime.Now,
            };

            _context.Incidents.Add(incident);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = incident.Id }, incident);
        }

        // POST api/incidents/5/upload-photo
        [HttpPost("{id}/upload-photo")]
        public async Task<IActionResult> UploadPhoto(int id, IFormFile file)
        {
            var incident = await _context.Incidents.FindAsync(id);
            if (incident == null)
                return NotFound();

            if (file == null || file.Length == 0)
                return BadRequest("مفيش صورة اتبعتت.");

            var photosFolder = Path.Combine(_env.WebRootPath, "incident-photos");
            Directory.CreateDirectory(photosFolder);

            var fileName = $"{Guid.NewGuid()}_{file.FileName}";
            var fullPath = Path.Combine(photosFolder, fileName);

            using (var stream = new FileStream(fullPath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }

            incident.PhotoPath = $"/incident-photos/{fileName}";
            await _context.SaveChangesAsync();

            return Ok(new { path = incident.PhotoPath });
        }

        // PUT api/incidents/5/investigate
        [HttpPut("{id}/investigate")]
        public async Task<IActionResult> MarkUnderInvestigation(int id)
        {
            var incident = await _context.Incidents.FindAsync(id);
            if (incident == null)
                return NotFound();

            incident.Status = "UnderInvestigation";
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // PUT api/incidents/5/close
        [HttpPut("{id}/close")]
        public async Task<IActionResult> Close(int id)
        {
            var incident = await _context.Incidents.FindAsync(id);
            if (incident == null)
                return NotFound();

            incident.Status = "Closed";
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}