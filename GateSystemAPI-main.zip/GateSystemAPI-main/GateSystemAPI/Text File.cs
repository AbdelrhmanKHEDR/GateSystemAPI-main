﻿namespace GateSystemAPI
{
    public class Text_File
    {
    }
}
