﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GateSystemAPI.Migrations
{
    /// <inheritdoc />
    public partial class AddDurationToVisitLogs : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "DurationMinutes",
                table: "VisitLogs",
                type: "int",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DurationMinutes",
                table: "VisitLogs");
        }
    }
}
