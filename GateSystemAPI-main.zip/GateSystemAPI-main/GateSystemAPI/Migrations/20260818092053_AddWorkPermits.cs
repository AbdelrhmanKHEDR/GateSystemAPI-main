﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GateSystemAPI.Migrations
{
    /// <inheritdoc />
    public partial class AddWorkPermits : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "WorkPermits",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PermitNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PermitType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    WorkLocation = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    WorkDescription = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Hazards = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ControlMeasures = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PpeRequired = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsolationLoto = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    StartDateTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    EndDateTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ExtensionRequired = table.Column<bool>(type: "bit", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Requester = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SupervisorApproved = table.Column<bool>(type: "bit", nullable: true),
                    HseApproved = table.Column<bool>(type: "bit", nullable: true),
                    SecurityApproved = table.Column<bool>(type: "bit", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WorkPermits", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "WorkPermits");
        }
    }
}
