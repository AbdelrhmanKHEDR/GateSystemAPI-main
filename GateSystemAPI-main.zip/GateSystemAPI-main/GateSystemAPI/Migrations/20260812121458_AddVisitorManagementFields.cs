﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GateSystemAPI.Migrations
{
    /// <inheritdoc />
    public partial class AddVisitorManagementFields : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "AccessArea",
                table: "VisitLogs",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "ApprovalRequired",
                table: "VisitLogs",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "BadgeNumber",
                table: "VisitLogs",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Department",
                table: "VisitLogs",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "HostEmployee",
                table: "VisitLogs",
                type: "nvarchar(max)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AccessArea",
                table: "VisitLogs");

            migrationBuilder.DropColumn(
                name: "ApprovalRequired",
                table: "VisitLogs");

            migrationBuilder.DropColumn(
                name: "BadgeNumber",
                table: "VisitLogs");

            migrationBuilder.DropColumn(
                name: "Department",
                table: "VisitLogs");

            migrationBuilder.DropColumn(
                name: "HostEmployee",
                table: "VisitLogs");
        }
    }
}
