﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GateSystemAPI.Migrations
{
    /// <inheritdoc />
    public partial class AddVisitorContactAndStatusFields : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ExpectedTime",
                table: "VisitLogs",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "MobileOrId",
                table: "VisitLogs",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Notes",
                table: "VisitLogs",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Status",
                table: "VisitLogs",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "VisitPurpose",
                table: "VisitLogs",
                type: "nvarchar(max)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ExpectedTime",
                table: "VisitLogs");

            migrationBuilder.DropColumn(
                name: "MobileOrId",
                table: "VisitLogs");

            migrationBuilder.DropColumn(
                name: "Notes",
                table: "VisitLogs");

            migrationBuilder.DropColumn(
                name: "Status",
                table: "VisitLogs");

            migrationBuilder.DropColumn(
                name: "VisitPurpose",
                table: "VisitLogs");
        }
    }
}
