﻿using Microsoft.EntityFrameworkCore;
using GateSystemAPI.Models;

namespace GateSystemAPI.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<Contractor> Contractors { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<VisitLog> VisitLogs { get; set; }
        public DbSet<WorkPermit> WorkPermits { get; set; }
        public DbSet<Inspection> Inspections { get; set; }
        public DbSet<ContractorDocument> ContractorDocuments { get; set; }
        public DbSet<Incident> Incidents { get; set; }
    }
}