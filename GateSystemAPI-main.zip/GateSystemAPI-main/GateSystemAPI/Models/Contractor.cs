﻿namespace GateSystemAPI.Models
{
    public class Contractor
    {
        public int Id { get; set; }
        public string? NationalId { get; set; }
        public string PhoneNumber { get; set; } = string.Empty;
        public string FullName { get; set; } = string.Empty;
        public string CompanyName { get; set; } = string.Empty;
        public bool IsBlacklisted { get; set; }
        public string? Notes { get; set; }

        public string? ContractorType { get; set; }
        public string? RiskCategory { get; set; }
        public string? AccessEligibility { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}