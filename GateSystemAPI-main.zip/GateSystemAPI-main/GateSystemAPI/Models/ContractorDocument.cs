﻿namespace GateSystemAPI.Models
{
    public class ContractorDocument
    {
        public int Id { get; set; }
        public int ContractorId { get; set; }

        public string DocumentType { get; set; } = string.Empty;
        public string? DocumentNumber { get; set; }
        public DateTime? IssueDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public string? AttachmentPath { get; set; }

        public Contractor? Contractor { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}