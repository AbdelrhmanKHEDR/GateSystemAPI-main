﻿namespace GateSystemAPI.Models
{
    public class WorkPermit
    {
        public int Id { get; set; }
        public string PermitNumber { get; set; } = string.Empty;
        public string PermitType { get; set; } = string.Empty;
        public string? WorkLocation { get; set; }
        public string? WorkDescription { get; set; }

        public string? Hazards { get; set; }
        public string? ControlMeasures { get; set; }
        public string? PpeRequired { get; set; }
        public string? IsolationLoto { get; set; }

        public DateTime StartDateTime { get; set; }
        public DateTime? EndDateTime { get; set; }
        public bool ExtensionRequired { get; set; }
        public string Status { get; set; } = "Pending";

        public string? Requester { get; set; }
        public bool? SupervisorApproved { get; set; }
        public bool? HseApproved { get; set; }
        public bool? SecurityApproved { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}