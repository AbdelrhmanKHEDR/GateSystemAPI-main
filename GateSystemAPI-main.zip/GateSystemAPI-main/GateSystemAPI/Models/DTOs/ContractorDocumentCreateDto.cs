﻿namespace GateSystemAPI.Models.DTOs
{
    public class ContractorDocumentCreateDto
    {
        public string DocumentType { get; set; } = string.Empty;
        public string? DocumentNumber { get; set; }
        public DateTime? IssueDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
    }
}