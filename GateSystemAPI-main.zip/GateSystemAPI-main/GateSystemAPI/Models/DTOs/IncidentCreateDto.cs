﻿namespace GateSystemAPI.Models.DTOs
{
    public class IncidentCreateDto
    {
        public string IncidentType { get; set; } = string.Empty;
        public DateTime IncidentDateTime { get; set; }
        public string? Location { get; set; }

        public string? PersonsInvolved { get; set; }
        public string? ReportedBy { get; set; }
        public string? Description { get; set; }
        public string InitialSeverity { get; set; } = "Medium";

        public string? ImmediateAction { get; set; }
        public string? Investigator { get; set; }
        public string? RootCause { get; set; }

        public string? CorrectiveAction { get; set; }
        public string? ResponsiblePerson { get; set; }
        public DateTime? DueDate { get; set; }
        public string? VerificationStatus { get; set; }
    }
}