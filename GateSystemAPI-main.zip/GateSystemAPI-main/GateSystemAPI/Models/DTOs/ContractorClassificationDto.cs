﻿namespace GateSystemAPI.Models.DTOs
{
    public class ContractorClassificationDto
    {
        public string? ContractorType { get; set; }
        public string? RiskCategory { get; set; }
        public string? AccessEligibility { get; set; }
    }
}