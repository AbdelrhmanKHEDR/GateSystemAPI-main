﻿namespace GateSystemAPI.Models.DTOs
{
    public class VisitLogUpdateDto
    {
        public string? HostEmployee { get; set; }
        public string? Department { get; set; }
        public bool ApprovalRequired { get; set; }
        public string? AccessArea { get; set; }
        public string? BadgeNumber { get; set; }
        public string? MobileOrId { get; set; }
        public string? VisitPurpose { get; set; }
        public string? ExpectedTime { get; set; }
        public string? Status { get; set; }
        public string? Notes { get; set; }
    }
}