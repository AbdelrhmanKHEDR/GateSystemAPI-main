﻿namespace GateSystemAPI.Models.DTOs
{
    public class VisitLogCreateDto
    {
        public int ContractorId { get; set; }
        public int RecordedByUserId { get; set; }
        public string VisitReason { get; set; } = string.Empty;

        public string? HostEmployee { get; set; }
        public string? Department { get; set; }
        public bool ApprovalRequired { get; set; }
        public string? AccessArea { get; set; }
        public string? BadgeNumber { get; set; }
        public string? MobileOrId { get; set; }
        public string? VisitPurpose { get; set; }
        public string? ExpectedTime { get; set; }
        public string? Status { get; set; }
        public string? Notes { get; set; }
    }
}