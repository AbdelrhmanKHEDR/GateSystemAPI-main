﻿namespace GateSystemAPI.Models.DTOs
{
    public class WorkPermitCreateDto
    {
        public string PermitType { get; set; } = string.Empty;
        public string? WorkLocation { get; set; }
        public string? WorkDescription { get; set; }

        public string? Hazards { get; set; }
        public string? ControlMeasures { get; set; }
        public string? PpeRequired { get; set; }
        public string? IsolationLoto { get; set; }

        public DateTime StartDateTime { get; set; }
        public DateTime? EndDateTime { get; set; }
        public bool ExtensionRequired { get; set; }

        public string? Requester { get; set; }
    }
}