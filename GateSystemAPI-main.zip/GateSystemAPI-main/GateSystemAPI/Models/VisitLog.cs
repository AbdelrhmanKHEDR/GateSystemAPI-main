﻿namespace GateSystemAPI.Models
{
    public class VisitLog
    {
        public int Id { get; set; }
        public int ContractorId { get; set; }
        public int RecordedByUserId { get; set; }
        public string VisitReason { get; set; } = string.Empty;
        public DateTime EntryTime { get; set; } = DateTime.Now;
        public DateTime? ExitTime { get; set; }
        public int? DurationMinutes { get; set; }
        public string? PermitFilePath { get; set; }

        // Host & Approval (Visitor Management fields)
        public string? HostEmployee { get; set; }
        public string? Department { get; set; }
        public bool ApprovalRequired { get; set; }
        public string? AccessArea { get; set; }
        public string? BadgeNumber { get; set; }

        // Contact & Status (Visitor Management fields - part 2)
        public string? MobileOrId { get; set; }
        public string? VisitPurpose { get; set; }
        public string? ExpectedTime { get; set; }
        public string? Status { get; set; }
        public string? Notes { get; set; }

        public Contractor? Contractor { get; set; }
        public User? RecordedByUser { get; set; }
    }
}