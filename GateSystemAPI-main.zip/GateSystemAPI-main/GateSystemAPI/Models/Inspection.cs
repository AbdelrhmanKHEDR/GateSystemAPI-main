﻿namespace GateSystemAPI.Models
{
    public class Inspection
    {
        public int Id { get; set; }
        public string InspectionType { get; set; } = string.Empty;
        public string? AreaOrAsset { get; set; }
        public string? Inspector { get; set; }
        public DateTime InspectionDate { get; set; }

        public string? ChecklistItem { get; set; }
        public string Result { get; set; } = "Compliant";
        public string? RiskLevel { get; set; }
        public string? Comment { get; set; }

        public string? PhotoPath { get; set; }
        public string? FindingDescription { get; set; }
        public string? ImmediateAction { get; set; }

        public string? ActionOwner { get; set; }
        public DateTime? DueDate { get; set; }
        public string? Priority { get; set; }
        public string ActionStatus { get; set; } = "Open";

        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}